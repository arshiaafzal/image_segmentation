function [c,ur,ug,ub]=cluster(input,x,y,k)
input_r=input(:,:,1);
input_g=input(:,:,2);
input_b=input(:,:,3);

input_g=conv2(input_g,1,'same');
input_b=conv2(input_b,1,'same');
input_r=conv2(input_r,1,'same');

ur=input_r(x,y);
ug=input_g(x,y);
ub=input_b(x,y);

N=size(input,1)*size(input,2);
c=zeros(size(input,1),size(input,2));
cb=ones(size(input,1),size(input,2));
M=zeros(k,1);

while(1)
    
for i=1:N
    
    for j=1:k
    M(j) = abs(ur(j)-input_r(i)) + abs(ug(j)-input_g(i)) + abs(ub(j)-input_b(i));
    end
    
    
    c(i)=find(M==min(M),1);
    
end

if(c==cb)
    break;
end

cb=c;

for o=1:k
f=find(c==o);
ur(o)=mean(input_r(f));
ug(o)=mean(input_g(f));
ub(o)=mean(input_b(f));
end




end


end