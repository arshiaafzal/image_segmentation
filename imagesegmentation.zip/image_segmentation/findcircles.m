function [N,D]=findcircles(input,r1,r2,image_location)
G=input;
[x,y]=find(G);
x0=linspace(1,size(G,1),size(G,1));
y0=linspace(1,size(G,2),size(G,2));

C=zeros(length(x0),length(y0));

for k=1:length(y0)
  for i=1:length(x0)
   
    r=sqrt((x-x0(i)).^2+(y-y0(k)).^2);
    
    l= length (find(r>r1 & r<r2));
    C(i,k)=C(i,k)+l;
   
   
   
 end
end
 if (r1<25)
   Clim=200;
 else 
   Clim= round(510/(1+10*exp(-r1/20)));
 end
 [xc, yc]=find(C>Clim);
 theta=linspace(0,2*pi,1000);
 if (ischar(image_location))
 D=imread(image_location);
 D=rgb2gray(D);
 else 
     D=image_location;
 end
 iter=0;
for p=1:length(theta)
 for o=1:length(xc)
     
   s=1;
   if (o~=1)
    for h=1:o-1
       s = s && (xc(o)>xc(h)+8 || xc(o)<xc(h)-8 || yc(o)>yc(h)+8 || yc(o)<yc(h)-8 );
    end
   end
   
    if(s)
   D(round(xc(o)+0.5*(r1+r2)*cos(theta(p))),round(yc(o)+0.5*(r1+r2)*sin(theta(p))))=1;
   iter=iter+1;
    end
   
   
   
 end
end
  imshow(D); 
  N=iter/length(theta);
end
