function d=otsu(input)
sigma=zeros(1,256);
[counts,bl]=imhist(input);

for i=1:256
counts(i)= counts(i)*bl(i);
end

for t=1:256
    
  p1=counts(1:t);
  p2=counts(t+1:256);
  
  q1=sum(p1);
  q2=sum(p2);


  u1 = sum(bl(1:t).*p1)/q1;
  u2 = sum(bl(t+1:256).*p2)/q2;
  
  sigma(t)= q1*(q2)*(u1-u2)^2;
    
end

l=sigma==max(sigma);
level=bl(l);

d=imbinarize(input,level);
