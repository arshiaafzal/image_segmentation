%%  ======================= detecting circle using haugh transform ========================
%% ============= initializing the image================
clc;
clear;
y=imread('circles.jpg');
figure;
imshow(y);
title('image');
y=rgb2gray(y);
Gx=[-1 0 1;-2 0 2;-1 0 1];
Gy=[-1 -2 -1;0 0 0;1 2 1];
gx=conv2(y,Gx,'same');
gy=conv2(y,Gy,'same');
G=sqrt(gx.^2+gy.^2);
G=8*mat2gray(G);
G=imbinarize(G);

figure;
imshow(G);
title('binery image');
%% detecting circles using my function
clc;
[N,D]=findcircles(G,20,24,'circles.jpg'); % image 1

%% using the matlab function for detection
clc;
clear;
rgb = imread('circles.jpg');
[centers,radii] = imfindcircles(rgb,[20 25],'ObjectPolarity','dark', ...
    'Sensitivity',0.9);
imshow(rgb)
h = viscircles(centers,radii);
[centers,radii] = imfindcircles(rgb,[20 25],'ObjectPolarity','dark', ...
    'Sensitivity',0.92);

length(centers)

h = viscircles(centers,radii);
[centers,radii] = imfindcircles(rgb,[20 25],'ObjectPolarity','dark', ...
          'Sensitivity',0.92,'Method','twostage');


h = viscircles(centers,radii);
[centers,radii] = imfindcircles(rgb,[20 25],'ObjectPolarity','dark', ...
          'Sensitivity',0.95);



[centersBright,radiiBright,metricBright] = imfindcircles(rgb,[20 25], ...
    'ObjectPolarity','bright','Sensitivity',0.92,'EdgeThreshold',0.1);


hBright = viscircles(centersBright, radiiBright,'Color','b');

%% ======================= clustering using k-means ========================
%%
% clustering image 2
clc;
clear;
input=imread('img2.jpeg');
imshow(input);
[c,ur,ug,ub]=cluster(input,[400,200,50],[300,400,200],3);
figure;
if (abs(ur(1)-ur(2))+abs(ug(1)-ug(2))+abs(ub(1)-ub(2))>abs(ur(1)-ur(3))+abs(ug(1)-ug(3))+abs(ub(1)-ub(3)))
   t=c==2;
   c(t)=1;
else
    t=c==3;
    c(t)=1;
end
imagesc(c);
%%
%clustering image 1
clc;
clear;
input=imread('img1.jpg');
imshow(input);
[c,ur,ug,ub]=cluster(input,[400,200,50,100,2,540],[190,80,90,200,400,300],6);
figure;
imagesc(c);

%%
%otsu image 2
clc; 
clear;
input=imread('img2.jpeg');
input=rgb2gray(input);
input=mat2gray(input);
imhist(input);
figure; 
imshow(otsu(input));
%%
%otsu image 1
clc; 
clear;
input=imread('img1.jpg');
input=rgb2gray(input);
input=mat2gray(input);
imhist(input);
figure; 
imshow(otsu(input));









